import json

with open("twitter_small.json", "r", encoding="utf-8") as f:

    daten = json.load(f)

#print(daten["tweets"])
#print(json.dumps(daten["tweets"], indent= 4))



class Tweets:

    def getJson(self):
        with open("twitter_small.json", "r", encoding="utf-8") as fileSmall, open("t"):

            daten = json.load(f)
        for i in daten:
            return daten

    def __repr__(self):
        return daten
    def __str__(self):
        return daten

r1 = Tweets.getJson(self)

print()


