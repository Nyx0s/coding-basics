"""
<U1 Bsp. 2>
<Multiplizierer>
<Maximilian Jonas, 52203295>
"""
### Multiplizeren zweier Variablen die der User mit numerischen Werten versieht

# eval(input()) um nur zahlen in den Variablen zu speichern

x = eval(input("Zahl1: ")) # x speichert Zahl1
y = eval(input("Zahl2: ")) # y speichert Zahl2

print(f"Rechnung {x} * {y} = {x*y}") # Ausgabe der Zahl1 * Zahl2