"""
<U1 Bsp. 1>
<String Manipulation>
<Maximilian Jonas, 52203295>
"""

text = "PROG VO bis" # gegebener String

### Ausgabe der ersten 4 Zeichen des Strings

firstFour = text[:4] # speichern der ersten 4 Zeichen in firstFour Variable

print(firstFour) # Ausgabe firstFour Variable

### Teil "VO" ausgeben

middlePart = text[5:7] # speichern des 4-6 Zeichen in middlePart Variable

print(middlePart)

### Ausgabe der ersten 4 Zeichen des Strings

lastTwo = text[-2::] # speichern der letzen 2 Zeichen in lastTwo Variable

print(lastTwo) # Ausgabe firstFour Variable

### Ausgabe der länge des Strings

lenText = len(text) # speichern der länge des Strings in der lenText Variable

print(len(text)) # Ausgabe firstFour Variable
